# GooseLite - Goose Goose Duck-like plugin (Static Lobby World)

This project is a ready-to-build Paper plugin skeleton implementing a Goose Goose Duck-inspired minigame.

## What is included
- Static Lobby World support (configure coordinates in `config.yml`)
- Role system with many GGD-inspired roles (all roles present as enum entries)
- Lobby + countdown + auto-start
- Basic game flow (LOBBY -> INGAME -> VOTING -> END)
- Voting GUI placeholder, meetings, kill cooldown, simple tasks placeholder
- `config.yml` with role toggles and role settings
- `plugin.yml` and Maven `pom.xml`

## Build
You need JDK 21 and Maven installed.

From project root:
```bash
mvn clean package
```
The produced JAR will be in `target/gooselite-1.0.0.jar`.

If you don't have Maven locally, you can use:
- Replit, GitHub Actions, or an online Maven build service to create the jar.

## Installation
1. Put the generated jar into your Paper server `/plugins/` folder.
2. Start the server to generate the data folder and config.
3. Edit `plugins/GooseLite/config.yml` to configure lobby coords and role toggles.
4. Use `/ggd join` to join the lobby, `/ggd start` to start, etc.

## Notes
- This project intentionally **does not** include any copyrighted assets from Goose Goose Duck.
- Roles are implemented as enum placeholders; individual role abilities can be added in `roles/` handlers.

Enjoy! If you want, I can extend role behaviors, add GUI, or produce a compiled JAR with GitHub Actions configuration.

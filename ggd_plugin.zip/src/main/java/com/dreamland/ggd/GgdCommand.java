package com.dreamland.ggd;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class GgdCommand implements CommandExecutor {
    private final GameManager gm;
    private final LobbyManager lm;

    public GgdCommand(GameManager gm, LobbyManager lm){
        this.gm = gm;
        this.lm = lm;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args){
        if(!(sender instanceof Player)){
            sender.sendMessage("Use in-game only.");
            return true;
        }
        Player p = (Player) sender;
        if(args.length==0){
            p.sendMessage("/ggd join|leave|start|status|vote");
            return true;
        }
        String sub = args[0].toLowerCase();
        switch(sub){
            case "join":
                if(lm.joinLobby(p)) p.sendMessage("Pridal/a si sa do lobby.");
                else p.sendMessage("Momentálne nemôžeš vstúpiť do lobby.");
                break;
            case "leave":
                lm.leaveLobby(p);
                p.sendMessage("Opustil/a si lobby.");
                break;
            case "start":
                if(p.hasPermission("gooselite.admin")) gm.startGame();
                else p.sendMessage("Nemáš právo spustiť hru.");
                break;
            case "status":
                p.sendMessage("Stav: " + gm.getState());
                p.sendMessage("Hráči v lobby: " + gm.getLobby().size());
                break;
            case "vote":
                gm.startVoting();
                p.sendMessage("Hlasovanie spustené.");
                break;
            default:
                p.sendMessage("Unknown subcommand.");
        }
        return true;
    }
}

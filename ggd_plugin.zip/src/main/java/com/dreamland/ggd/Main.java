package com.dreamland.ggd;

import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {
    private static Main instance;
    private GameManager gameManager;
    private LobbyManager lobbyManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        this.gameManager = new GameManager(this);
        this.lobbyManager = new LobbyManager(this, gameManager);

        getCommand("ggd").setExecutor(new GgdCommand(gameManager, lobbyManager));

        getServer().getPluginManager().registerEvents(new PlayerListeners(gameManager, lobbyManager), this);

        getLogger().info("GooseLite enabled.");
    }

    @Override
    public void onDisable() {
        getLogger().info("GooseLite disabled.");
    }

    public static Main getInstance() { return instance; }
    public GameManager getGameManager() { return gameManager; }
    public LobbyManager getLobbyManager() { return lobbyManager; }
}

package com.dreamland.ggd;

/**
 * Roles enum: many Goose Goose Duck-inspired roles are listed here as identifiers.
 * Each role has a display name. Abilities are left as extension points.
 */
public enum Role {
    GOOSE("Goose"),
    DUCK("Duck"),
    SHERIFF("Sheriff"),
    VIGILANTE("Vigilante"),
    TECHNICIAN("Technician"),
    LOVER("Lover"),
    DETECTIVE("Detective"),
    ASTRAL("Astral"),
    MORPHLING("Morphling"),
    IDENTITY_THIEF("Identity Thief"),
    PROFESSIONAL("Professional"),
    CANNIBAL("Cannibal"),
    WARLOCK("Warlock"),
    SILENCER("Silencer"),
    MEDIUM("Medium"),
    ENGINEER("Engineer"),
    MEDIC("Medic"),
    TRAITOR("Traitor"),
    PHANTOM("Phantom"),
    HUBRIS("Hubris"),
    // add more role identifiers as needed
    NEUTRAL("Neutral");

    private final String display;
    Role(String display){ this.display = display; }
    public String displayName(){ return display; }
}

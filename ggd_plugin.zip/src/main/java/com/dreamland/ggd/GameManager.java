package com.dreamland.ggd;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class GameManager {
    public enum State { LOBBY, COUNTDOWN, INGAME, VOTING, END }
    private final Main plugin;
    private State state = State.LOBBY;
    private final Set<UUID> lobby = new HashSet<>();
    private final Map<UUID, Role> roles = new HashMap<>();
    private final Set<UUID> alive = new HashSet<>();
    private int killCooldown;
    private final Map<UUID, Long> lastKill = new HashMap<>();
    private int countdownTaskId = -1;
    private int countdownSeconds = 30;

    public GameManager(Main plugin){
        this.plugin = plugin;
        this.killCooldown = plugin.getConfig().getInt("game.kill_cooldown", 10);
        this.countdownSeconds = plugin.getConfig().getInt("game.auto_start_countdown", 30);
    }

    /* Lobby management */
    public boolean join(Player p){
        if(state != State.LOBBY && state != State.COUNTDOWN) return false;
        lobby.add(p.getUniqueId());
        broadcast(p.getName() + " sa pridal/a do lobby ("+lobby.size()+").");
        // auto-start if enough players
        if(lobby.size() >= plugin.getConfig().getInt("game.min_players", 4) && state == State.LOBBY){
            startCountdown();
        }
        return true;
    }
    public void leave(Player p){
        lobby.remove(p.getUniqueId());
        roles.remove(p.getUniqueId());
        alive.remove(p.getUniqueId());
        broadcast(p.getName() + " opustil/a lobby.");
        if(lobby.size() < plugin.getConfig().getInt("game.min_players", 4) && state == State.COUNTDOWN){
            stopCountdown();
        }
    }

    private void startCountdown(){
        if(state != State.LOBBY) return;
        state = State.COUNTDOWN;
        final int[] t = {countdownSeconds};
        broadcast("Hra sa spustí o " + t[0] + " sekúnd...");
        new BukkitRunnable(){
            @Override
            public void run() {
                if(state != State.COUNTDOWN) { this.cancel(); return; }
                t[0]--;
                if(t[0] <= 0){
                    startGame();
                    cancel();
                } else if(t[0] % 5 == 0 || t[0] <= 5){
                    broadcast("Hra sa spustí o " + t[0] + " sekúnd...");
                }
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }
    private void stopCountdown(){
        if(state != State.COUNTDOWN) return;
        state = State.LOBBY;
        broadcast("Odpočítavanie zrušené (nedostatok hráčov).");
    }

    public void startGame(){
        if(state == State.INGAME) return;
        if(lobby.size() < plugin.getConfig().getInt("game.min_players", 4)){
            broadcast("Nedostatok hráčov pre štart.");
            state = State.LOBBY;
            return;
        }
        assignRoles();
        state = State.INGAME;
        alive.clear();
        lobby.forEach(alive::add);
        broadcast("Hra začala! Role rozdelené.");
        // example repeating task for in-game updates
        new BukkitRunnable(){
            int t = 0;
            @Override
            public void run() {
                if(state != State.INGAME) cancel();
                t++;
                if(t % 30 == 0) broadcast("Prebehlo " + t + " sekúnd hry.");
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }

    private void assignRoles(){
        roles.clear();
        List<UUID> players = new ArrayList<>(lobby);
        Collections.shuffle(players);
        int total = players.size();
        int ducks = Math.max(1, (int)Math.round(total * plugin.getConfig().getDouble("role-settings.percent_ducks", 0.20)));
        int neutrals = Math.max(0, (int)Math.round(total * plugin.getConfig().getDouble("role-settings.percent_neutrals", 0.10)));
        // assign ducks first
        for(int i=0;i<players.size();i++){
            UUID id = players.get(i);
            if(i < ducks) roles.put(id, Role.DUCK);
            else if(i < ducks + neutrals) roles.put(id, Role.MEDIUM); // simple neutral placeholder
            else roles.put(id, Role.GOOSE);
        }
        // notify each player privately
        roles.forEach((id, role)->{
            Player p = Bukkit.getPlayer(id);
            if(p!=null){
                p.sendMessage("Tvoja rola: " + role.displayName());
            }
        });
    }

    public Role getRole(UUID id){ return roles.getOrDefault(id, Role.GOOSE); }

    public boolean canKill(UUID killer){
        Long last = lastKill.get(killer);
        if(last == null) return true;
        return (System.currentTimeMillis() - last) >= killCooldown*1000;
    }
    public void recordKill(UUID killer){
        lastKill.put(killer, System.currentTimeMillis());
    }

    public void broadcast(String msg){
        lobby.forEach(u -> {
            Player p = Bukkit.getPlayer(u);
            if(p!=null) p.sendMessage(msg);
        });
    }

    public Set<UUID> getLobby(){ return Collections.unmodifiableSet(lobby); }
    public State getState(){ return state; }
    public Set<UUID> getAlive(){ return Collections.unmodifiableSet(alive); }

    // Voting helpers (placeholder)
    public void startVoting(){
        if(state != State.INGAME) return;
        state = State.VOTING;
        broadcast("Hlasovanie začalo! Použi /ggd vote <meno> alebo GUI.");
        Bukkit.getScheduler().runTaskLater(plugin, this::finishVoting, 20*30);
    }
    private void finishVoting(){
        // naive random eject if demo
        List<UUID> candidates = new ArrayList<>(alive);
        if(candidates.isEmpty()) return;
        UUID ejected = candidates.get(new Random().nextInt(candidates.size()));
        Player p = Bukkit.getPlayer(ejected);
        if(p!=null){
            broadcast(p.getName() + " bol vylúčený.");
            alive.remove(ejected);
        }
        state = State.INGAME;
    }
}

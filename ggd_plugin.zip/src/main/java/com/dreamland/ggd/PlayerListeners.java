package com.dreamland.ggd;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;

public class PlayerListeners implements Listener {
    private final GameManager gm;
    private final LobbyManager lm;
    public PlayerListeners(GameManager gm, LobbyManager lm){ this.gm = gm; this.lm = lm; }

    @EventHandler
    public void onQuit(PlayerQuitEvent e){
        lm.leaveLobby(e.getPlayer());
        // remove from game if present
    }

    @EventHandler
    public void onInteractEntity(PlayerInteractEntityEvent e){
        if(e.getHand() == EquipmentSlot.OFF_HAND) return;
        Player p = e.getPlayer();
        if(gm.getState() != GameManager.State.INGAME) return;
        Role role = gm.getRole(p.getUniqueId());
        if(e.getRightClicked() instanceof Player && p.getInventory().getItemInMainHand().getType() == Material.WOODEN_SWORD){
            Player target = (Player) e.getRightClicked();
            if(role == Role.DUCK && gm.canKill(p.getUniqueId())){
                gm.recordKill(p.getUniqueId());
                gm.broadcast(p.getName()+" zabil/a " + target.getName() + "!");
                target.setHealth(0.0);
            } else {
                p.sendMessage("Nemôžeš momentálne zabiť (cooldown / nie si Duck).");
            }
        }
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent e){
        // simple handling: if player dies in-game, remove from alive set
        if(gm.getState() == GameManager.State.INGAME){
            lm.onPlayerKilled(e.getEntity());
        }
    }
}

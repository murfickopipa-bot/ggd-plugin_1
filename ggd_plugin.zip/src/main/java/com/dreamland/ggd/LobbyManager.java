package com.dreamland.ggd;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

import java.util.UUID;

public class LobbyManager {
    private final Main plugin;
    private final GameManager gm;

    public LobbyManager(Main plugin, GameManager gm){
        this.plugin = plugin;
        this.gm = gm;
    }

    public boolean joinLobby(Player p){
        if(!plugin.getConfig().getBoolean("lobby.use_static_coords", true)) return false;
        String worldName = plugin.getConfig().getString("lobby.world", "world");
        World w = Bukkit.getWorld(worldName);
        if(w == null) {
            p.sendMessage("Lobby world not found: " + worldName);
            return false;
        }
        double x = plugin.getConfig().getDouble("lobby.x", 0.5);
        double y = plugin.getConfig().getDouble("lobby.y", 65.0);
        double z = plugin.getConfig().getDouble("lobby.z", 0.5);
        float yaw = (float)plugin.getConfig().getDouble("lobby.yaw", 0.0);
        float pitch = (float)plugin.getConfig().getDouble("lobby.pitch", 0.0);
        Location loc = new Location(w, x, y, z, yaw, pitch);
        p.teleport(loc);
        gm.join(p);
        return true;
    }

    public void leaveLobby(Player p){
        gm.leave(p);
    }

    public void onPlayerKilled(Player p){
        gm.broadcast(p.getName() + " bol zabitý.");
    }
}

package com.dreamland.ggd;

import org.bukkit.entity.Player;

/**
 * Placeholder for Vote GUI. Implementation can be extended.
 */
public class VoteGUI {
    public static void openFor(Player p){
        p.sendMessage("Vote GUI is not yet implemented. Use /ggd vote <name> for now.");
    }
}
